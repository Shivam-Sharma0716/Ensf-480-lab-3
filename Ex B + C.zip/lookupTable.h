// lookupTable.h
// ENSF 480 - Lab 3, Ex C
// Completed By: [Shiv Sharma]
// Submission Date: [Sept 28, 2026]

#ifndef LOOKUPTABLE_H
#define LOOKUPTABLE_H
#include <iostream>
#include <cassert>
using namespace std;

template <class K, class D>
struct Pair
{
  Pair(K keyA, D datumA) : key(keyA), datum(datumA) {}
  K key;
  D datum;
};


template <class K, class D>
class LookupTable;

template <class K, class D>
class LT_Node {
  friend class LookupTable<K, D>;
private:
  Pair<K, D> pairM;
  LT_Node *nextM;

  LT_Node(const Pair<K, D>& pairA, LT_Node *nextA);
};

template <class K, class D>
class LookupTable {
public:

  class Iterator {
    friend class LookupTable;
    LookupTable *LT;
  public:
    Iterator() : LT(0) {}
    Iterator(LookupTable & x) : LT(&x) {}
    const D& operator *();
    const D& operator ++();
    const D& operator ++(int);
    int operator !();

    void step_fwd() { assert(LT->cursor_ok()); LT->step_fwd(); }
  };

  LookupTable();
  LookupTable(const LookupTable & source);
  LookupTable& operator =(const LookupTable& rhs);
  ~LookupTable();

  LookupTable& begin();

  int size() const;
  int cursor_ok() const;
  const K& cursor_key() const;
  const D& cursor_datum() const;

  void insert(const Pair<K, D>& pairA);
  void remove(const K& keyA);
  void find(const K& keyA);
  void go_to_first();
  void step_fwd();
  void make_empty();

  template <class K2, class D2>
  friend ostream& operator << (ostream& os, const LookupTable<K2, D2>& lt);

private:
  int sizeM;
  LT_Node<K, D> *headM;
  LT_Node<K, D> *cursorM;

  void destroy();
  void copy(const LookupTable& source);
};

// ---------- LT_Node constructor ----------
template <class K, class D>
LT_Node<K, D>::LT_Node(const Pair<K, D>& pairA, LT_Node<K, D> *nextA)
  : pairM(pairA), nextM(nextA)
{
}

// ---------- LookupTable member functions ----------

template <class K, class D>
LookupTable<K, D>& LookupTable<K, D>::begin()
{
  cursorM = headM;
  return *this;
}

template <class K, class D>
LookupTable<K, D>::LookupTable()
  : sizeM(0), headM(0), cursorM(0)
{
}

template <class K, class D>
LookupTable<K, D>::LookupTable(const LookupTable& source)
{
  copy(source);
}

template <class K, class D>
LookupTable<K, D>& LookupTable<K, D>::operator =(const LookupTable& rhs)
{
  if (this != &rhs) {
    destroy();
    copy(rhs);
  }
  return *this;
}

template <class K, class D>
LookupTable<K, D>::~LookupTable()
{
  destroy();
}

template <class K, class D>
int LookupTable<K, D>::size() const
{
  return sizeM;
}

template <class K, class D>
int LookupTable<K, D>::cursor_ok() const
{
  return cursorM != 0;
}

template <class K, class D>
const K& LookupTable<K, D>::cursor_key() const
{
  assert(cursor_ok());
  return cursorM->pairM.key;
}

template <class K, class D>
const D& LookupTable<K, D>::cursor_datum() const
{
  assert(cursor_ok());
  return cursorM->pairM.datum;
}

template <class K, class D>
void LookupTable<K, D>::insert(const Pair<K, D>& pairA)
{
  if (headM == 0 || pairA.key < headM->pairM.key) {
    headM = new LT_Node<K, D>(pairA, headM);
    sizeM++;
  }
  else if (pairA.key == headM->pairM.key)
    headM->pairM.datum = pairA.datum;
  else {
    LT_Node<K, D>* before = headM;
    LT_Node<K, D>* after = headM->nextM;

    while (after != NULL && (pairA.key > after->pairM.key)) {
      before = after;
      after = after->nextM;
    }

    if (after != NULL && pairA.key == after->pairM.key) {
      after->pairM.datum = pairA.datum;
    }
    else {
      before->nextM = new LT_Node<K, D>(pairA, before->nextM);
      sizeM++;
    }
  }
}

template <class K, class D>
void LookupTable<K, D>::remove(const K& keyA)
{
  if (headM == 0 || keyA < headM->pairM.key)
    return;

  LT_Node<K, D>* doomed_node = 0;
  if (keyA == headM->pairM.key) {
    doomed_node = headM;
    headM = headM->nextM;
    sizeM--;
  }
  else {
    LT_Node<K, D> *before = headM;
    LT_Node<K, D> *maybe_doomed = headM->nextM;
    while (maybe_doomed != 0 && keyA > maybe_doomed->pairM.key) {
      before = maybe_doomed;
      maybe_doomed = maybe_doomed->nextM;
    }

    if (maybe_doomed != 0 && maybe_doomed->pairM.key == keyA) {
      doomed_node = maybe_doomed;
      before->nextM = maybe_doomed->nextM;
      sizeM--;
    }
  }
  delete doomed_node;
}

template <class K, class D>
void LookupTable<K, D>::find(const K& keyA)
{
  LT_Node<K, D> *ptr = headM;
  while (ptr != NULL && ptr->pairM.key != keyA) {
    ptr = ptr->nextM;
  }
  cursorM = ptr;
}

template <class K, class D>
void LookupTable<K, D>::go_to_first()
{
  cursorM = headM;
}

template <class K, class D>
void LookupTable<K, D>::step_fwd()
{
  assert(cursor_ok());
  cursorM = cursorM->nextM;
}

template <class K, class D>
void LookupTable<K, D>::make_empty()
{
  destroy();
  sizeM = 0;
  cursorM = 0;
}

template <class K, class D>
void LookupTable<K, D>::destroy()
{
  LT_Node<K, D> *ptr = headM;
  while (ptr != NULL) {
    headM = headM->nextM;
    delete ptr;
    ptr = headM;
  }
  cursorM = NULL;
  sizeM = 0;
}

template <class K, class D>
void LookupTable<K, D>::copy(const LookupTable& source)
{
  headM = 0;
  cursorM = 0;

  if (source.headM == 0)
    return;

  for (LT_Node<K, D> *p = source.headM; p != 0; p = p->nextM) {
    insert(Pair<K, D>(p->pairM.key, p->pairM.datum));
    if (source.cursorM == p)
      find(p->pairM.key);
  }
}

// ---------- Iterator member functions ----------

template <class K, class D>
const D& LookupTable<K, D>::Iterator::operator *()
{
  assert(LT->cursor_ok());
  return LT->cursor_datum();
}

template <class K, class D>
const D& LookupTable<K, D>::Iterator::operator ++()
{
  assert(LT->cursor_ok());
  const D& x = LT->cursor_datum();
  LT->step_fwd();
  return x;
}

template <class K, class D>
const D& LookupTable<K, D>::Iterator::operator ++(int)
{
  assert(LT->cursor_ok());
  LT->step_fwd();
  return LT->cursor_datum();
}

template <class K, class D>
int LookupTable<K, D>::Iterator::operator!()
{
  return (LT->cursor_ok());
}

// ---------- operator << ----------

template <class K, class D>
ostream& operator << (ostream& os, const LookupTable<K, D>& lt)
{
  if (lt.cursor_ok())
    os << lt.cursor_key() << "  " << lt.cursor_datum();
  else
    os << "Not Found.";
  return os;
}

#endif