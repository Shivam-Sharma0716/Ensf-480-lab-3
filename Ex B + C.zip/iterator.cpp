// iterator.cpp
// ENSF 480 - Lab 3, Ex B
// Completed By: [Shiv Sharma]
// Submission Date: [Sept 28, 2026]

#include <iostream>
#include <cstring>
#include <assert.h>
#include "mystring2.h"

using namespace std;


template <class T>
class Vector {
public:

  class VectIter {
    friend class Vector;
  private:
    Vector *v;   
    int index;   
  public:
    VectIter(Vector& x);

    T operator++();
    // PROMISES: increments the iterator's index and returns the
    //           value of the element at the new index position. If
    //           index exceeds the size of the array it will
    //           be set to zero (circular).

    T operator++(int);
    // PROMISES: returns the value of the element at the current index
    //           position, then increments the index. If index exceeds
    //           the size of the array it will be set to zero (circular).

    T operator--();
    // PROMISES: decrements the iterator index, and returns the
    //           value of the element at the new index. If index is
    //           less than zero it will be set to the last element (circular).

    T operator--(int);
    // PROMISES: returns the value of the element at the current index
    //           position, then decrements the index. If index is less
    //           than zero it will be set to the last element (circular).

    T operator*();
    // PROMISES: returns the value of the element at the current index.
  };

  Vector(int sz);
  ~Vector();

  T& operator[](int i);
  // PROMISES: returns existing value in the ith element of array
  //           or sets a new value to the ith element in array.

  void ascending_sort();
  // PROMISES: sorts the vector values in ascending order.

private:
  T *array;                
  int size;               
  void swap(T&, T&);       
};




template <class T>
void Vector<T>::ascending_sort()
{
  for (int i = 0; i < size - 1; i++)
    for (int j = i + 1; j < size; j++)
      if (array[i] > array[j])
        swap(array[i], array[j]);
}

// ---------- Specialization for const char* ----------
// For const char*, the generic version compares pointer addresses,
// not string contents. This specialization uses strcmp so C-strings
// are sorted alphabetically.
// NOTE: must appear AFTER the generic ascending_sort definition.
template <>
void Vector<const char*>::ascending_sort()
{
  for (int i = 0; i < size - 1; i++)
    for (int j = i + 1; j < size; j++)
      if (strcmp(array[i], array[j]) > 0)
        swap(array[i], array[j]);
}

template <class T>
void Vector<T>::swap(T& a, T& b)
{
  T tmp = a;
  a = b;
  b = tmp;
}

template <class T>
T Vector<T>::VectIter::operator*()
{
  return v->array[index];
}

template <class T>
Vector<T>::VectIter::VectIter(Vector& x)
{
  v = &x;
  index = 0;
}

template <class T>
T Vector<T>::VectIter::operator++()
{
  index++;
  if (index >= v->size)
    index = 0;
  return v->array[index];
}

template <class T>
T Vector<T>::VectIter::operator++(int)
{
  T tmp = v->array[index];
  index++;
  if (index >= v->size)
    index = 0;
  return tmp;
}

template <class T>
T Vector<T>::VectIter::operator--()
{
  index--;
  if (index < 0)
    index = v->size - 1;
  return v->array[index];
}

template <class T>
T Vector<T>::VectIter::operator--(int)
{
  T tmp = v->array[index];
  index--;
  if (index < 0)
    index = v->size - 1;
  return tmp;
}

template <class T>
Vector<T>::Vector(int sz)
{
  size = sz;
  array = new T[sz];
  assert(array != NULL);
}

template <class T>
Vector<T>::~Vector()
{
  delete[] array;
  array = NULL;
}

template <class T>
T& Vector<T>::operator[](int i)
{
  return array[i];
}


// ---------- main ----------

int main()
{
  Vector<int> x(3);
  x[0] = 999;
  x[1] = -77;
  x[2] = 88;

  Vector<int>::VectIter iter(x);

  cout << "\n\nThe first element of vector x contains: " << *iter;

#if 1
  cout << "\nTesting an <int> Vector: " << endl;

  cout << "\n\nTesting sort";
  x.ascending_sort();

  for (int i = 0; i < 3; i++)
    cout << endl << iter++;

  cout << "\n\nTesting Prefix --:";
  for (int i = 0; i < 3; i++)
    cout << endl << --iter;

  cout << "\n\nTesting Prefix ++:";
  for (int i = 0; i < 3; i++)
    cout << endl << ++iter;

  cout << "\n\nTesting Postfix --";
  for (int i = 0; i < 3; i++)
    cout << endl << iter--;

  cout << endl;

  cout << "Testing a <Mystring> Vector: " << endl;
  Vector<Mystring> y(3);
  y[0] = "Bar";
  y[1] = "Foo";
  y[2] = "All";

  Vector<Mystring>::VectIter iters(y);

  cout << "\n\nTesting sort";
  y.ascending_sort();

  for (int i = 0; i < 3; i++)
    cout << endl << iters++;

  cout << "\n\nTesting Prefix --:";
  for (int i = 0; i < 3; i++)
    cout << endl << --iters;

  cout << "\n\nTesting Prefix ++:";
  for (int i = 0; i < 3; i++)
    cout << endl << ++iters;

  cout << "\n\nTesting Postfix --";
  for (int i = 0; i < 3; i++)
    cout << endl << iters--;

  cout << endl;

  cout << "Testing a <char *> Vector: " << endl;
  Vector<const char*> z(3);
  z[0] = "Orange";
  z[1] = "Pear";
  z[2] = "Apple";

  Vector<const char*>::VectIter iterchar(z);

  cout << "\n\nTesting sort";
  z.ascending_sort();

  for (int i = 0; i < 3; i++)
    cout << endl << iterchar++;

#endif

  cout << "\nProgram Terminated Successfully." << endl;

  return 0;
}